<!DOCTYPE html>
<html>
<head>
  <?php

  include"body/head.php";

  ?>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
   <?php

   include"body/header.php";

   ?>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
   <?php

   include"body/navbar.php";

   ?>
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
  <!-- Content Header (Page header) -->

    <div class="row">

      <div class="col-md-12">
          <!-- Content Header (Page header) -->
    <section class="content-header">
      <h3>
        DATA PENDAFTAR WORKSHOP
      </h3>

      <div>
        <div class="input-group">
          
        </div>


    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">

          <!-- /.box -->

          <div class="box">
            <div class="box-header">
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th width="5%">NO</th>
                  <th>NAMA PENDAFTAR</th>
                  <th>JURUSAN</th>
                  <th>NO HP</th>
                  <th width="20%">OPTION</th>
                </tr>
                </thead>
                <tbody>

                <?php
                 
                 include"../config/koneksi.php";
                  $no =0;

                      $sql = "select * from iptek_pendaftar order by id_pendaftar desc ";
                      $query = mysqli_query($konek,$sql);

                      while ( $data = mysqli_fetch_assoc($query))

                      {

                  $no++;
                  
                ?>

                <tr>
                  <th><?php echo $no?></th>
                  <th><?php echo $data['nama']?></th>
                  <th><?php echo $data['jurusan']?></th>
                  <th><?php echo $data['nohp']?></th>
                  <td><a href="cetak.php?cetak=<?php echo $data['id_pendaftar']?>" class="btn btn-primary btn-sm">CETAK</a>&nbsp;<a href="proses_pendaftar/proses_delete.php?hapus=<?php echo $data['id_pendaftar']?>" class="btn btn-info btn-sm">HAPUS</a>&nbsp;<a href="detail_pendaftar.php?id=<?php echo $data['id_pendaftar']?>" class="btn btn-danger btn-sm">DETAIL</a></td>
                </tr>
                <?php

                  }

                 ?>
                </tbody>
                <tfoot>
                  <tr>
                    <th width="5%">NO</th>
                    <th>NAMA PENDAFTAR</th>
                    <th>JURUSAN</th>
                    <th>NO HP</th>
                    <th width="20%">OPTION</th>
                  </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->

      </div>

    </div>
  <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php

  include"body/footer.php";

  ?>

  <!-- Control Sidebar -->
</div>
<!-- ./wrapper -->
<?php

  include"body/javascript.php";

?>

</body>
</html>
