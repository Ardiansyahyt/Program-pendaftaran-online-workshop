<?php 

  session_start();
  if($_SESSION['level'] != '1'){
      header('location:../'); 
  }
 ?>


<!DOCTYPE html>
<html>
<head>
  <?php
  
    include"body/head.php";
  
  ?>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
   <?php
   
     include"body/header.php";
   
   ?>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
   <?php
   
     include"body/navbar.php";
   
   ?>
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    
      <div class="row">
        <div class="col-md-12" style="margin-top: 150px;">
          <div class="row" id="custom1">
          <div class="col-md-1"></div>
          <div class="col-md-3">
            <img style="margin-top: 10px;" src="img/44.png" width="50%" height="150">
          </div>
          <div class="col-md-6">
            <font color="black"><h3><center>UNIT KEGIATAN MAHASISWA</center></h3>
            <h4><center>Ilmu Pengetahuan Teknologi Komputer</center></h4>
            <h4><center>(STMIKNH) Nurdin Hamzah Jambi</center></h4>
            <h4><center>SISTEM INFORMASI PENDAFTARAN WORKSHOP</center></h4>
            <h4><center>Jl. Kol. Abunjani Sipin - Kota Jambi - Telp. (0741) 66407</center></h4></font>
          </div>
          <div class="col-md-2"></div>
        </div><!-- penutup row -->
        </div>
      </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php
  
    include"body/footer.php";
  
  ?>

  <!-- Control Sidebar -->
</div>
<!-- ./wrapper -->
<?php

  include"body/javascript.php";

?>

</body>
</html>
