 <!-- sidebar: style can be found in sidebar.less -->
	<section class="sidebar">
	  <!-- Sidebar user panel -->
	  <div class="user-panel">
		<div class="pull-left image">
		  <img src="img/44.png" class="img-circle" alt="User Image">
		</div>
		<div class="pull-left info">
		  <p>UKM</p>
		  <a href="#"><i class="fa fa-circle text-success"></i> IPTEK</a>
		</div>
	  </div>
	  
	  <!-- sidebar menu: : style can be found in sidebar.less -->
	  <ul class="sidebar-menu">
		<li class="header">MAIN NAVIGATION</li>
		<li class="active treeview">
		 
		<li class="treeview">
		  <a href="#">
			<i class="fa fa-table"></i> <span>DATA PENDAFTAR</span>
			<span class="pull-right-container">
			  <i class="fa fa-angle-left pull-right"></i>
			</span>
		  </a>
		  <ul class="treeview-menu">
			<li><a href="pendaftar.php"><i class="fa fa-circle-o"></i>TERDAFTAR</a></li>
		  </ul>
		</li>

		
	  </ul>
	</section>
	<!-- /.sidebar -->