<footer class="main-footer">
	<strong>Copyright Hak Cipta &copy 2018-2019 <a href=""> Ar, IT Support, Semua Hak Dilindungi Undang-Undang</a>.</strong>
  </footer>