<!DOCTYPE html>
<html>
<head>
	<?php include "body/head.php"; ?>
</head>
<body onload="window.print();">

	<div class="container">
		<div class="row">
			<div class="col-md-12" style="margin-top: 50px;">
				<center>
					<h4>FORMULIR VERIFIKASI CALON PESERTA WORKSHOP</h4>
					<h4>UKM-IPTEK STMIK NURDIN HAMZAH JAMBI</h4>
					<h4>TAHUN 2018/2019</h4>
				</center>
				<table id="example1" class="table table-bordered table-striped">
                <thead>
                <?php
            
                  include"../config/koneksi.php"; 
                  
                  $id = @$_GET['cetak'];
                  $no = 0;
                  $sql = "select * from iptek_pendaftar order by $id=id_pendaftar desc";
                  $query = mysqli_query($konek,$sql);
                  $data = mysqli_fetch_array($query);
                    
                  $no++;   
                  
                  ?>
                
                <tr>  
                  <th>NAMA</th>
                  <th><?php echo $data['nama']?></th>
                </tr>  
                <tr>  
                  <th>JURUSAN</th>
                  <th><?php echo $data['jurusan']?></th>
                </tr>
                <tr>  
                  <th>ALAMAT</th>
                  <th><?php echo $data['alamat']?>
                </tr>
                <tr>  
                  <th>JENIS KELAMIN</th>
                  <th><?php echo $data['jk']?></th>
                </tr>
                <tr>  
                  <th>NO HP</th>
                  <th><?php echo $data['nohp']?></th>
                </tr>
                <tr>  
                  <th>EMAIL</th>
                  <th><?php echo $data['email']?></th>
                </tr>
                  <th>FOTO PESERTA</th>
                  <th><img src="../img_pendaftar/<?php echo $data['foto']?>" width="50" height="50" ></th>
                </tr>
                </tr>
                  <th><center>Paraf Peserta</center></th>
                  <th style="float: right;">
                  	Jambi, ________, _______, 2018
                  	<p>Petugas Verivikasi</p><br/><br/><br/><br/><br/><br/><br/><br/>
                  	<p><center>Panitia</center></p>
                  </th>
                </tr>
                </thead>
              </table>
              <p>Catatan :</p>
              <p>* pastikan biodata di atas sesuai dengan data diri anda yang asli, karena itu berguna untuk mengisi data di sertifikat</p>
              <p>* Biaya pendaftaran langsung kasih ke petugas yang berjaga sebanyak Rp. 35.000</p>
			</div>
		</div>
	</div><!-- penutup container -->

</body>
</html>