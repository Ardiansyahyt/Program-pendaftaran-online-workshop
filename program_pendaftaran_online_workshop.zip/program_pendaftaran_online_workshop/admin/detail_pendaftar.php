<!DOCTYPE html>
<html>
<head>
  <?php
  
  include"body/head.php";
  
  ?>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
   <?php
   
   include"body/header.php";
   
   ?>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
   <?php
   
   include"body/navbar.php";
   
   ?>
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
  <!-- Content Header (Page header) -->
  
    <div class="row">
    
      <div class="col-md-12">
          <!-- Content Header (Page header) -->
    <section class="content-header">
      <h3>
       DETAIL PENDAFTAR
      </h3>

      
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          
          <!-- /.box -->

          <div class="box">
            <div class="box-header">
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <?php
            
                  include"../config/koneksi.php"; 
                  
                  $id = $_GET['id'];
                  $no = 0;
                  $sql = "select * from iptek_pendaftar order by $id=id_pendaftar desc";
                  $query = mysqli_query($konek,$sql);
                  $data = mysqli_fetch_array($query);
                    
                  $no++;   
                  
                  ?>
                <tr>
                  <th>NO</th>
                  <th><?php echo $no?></th>
                </tr>
                <tr>  
                  <th>NAMA</th>
                  <th><?php echo $data['nama']?></th>
                </tr>  
                <tr>  
                  <th>JURUSAN</th>
                  <th><?php echo $data['jurusan']?></th>
                </tr>
                <tr>  
                  <th>ALAMAT</th>
                  <th><?php echo $data['alamat']?>
                </tr>
                <tr>  
                  <th>JENIS KELAMIN</th>
                  <th><?php echo $data['jk']?></th>
                </tr>
                <tr>  
                  <th>NO HP</th>
                  <th><?php echo $data['nohp']?></th>
                </tr>
                <tr>  
                  <th>EMAIL</th>
                  <th><?php echo $data['email']?></th>
                </tr>
                  <th>FOTO SEBELUM</th>
                  <th><img src="../img_pendaftar/<?php echo $data['foto']?>" width="50" height="50" ></th>
                </tr>
                </thead>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
    
      </div>
    
    </div>
  <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php
  
  include"body/footer.php";
  
  ?>

  <!-- Control Sidebar -->
</div>
<!-- ./wrapper -->
<?php

  include"body/javascript.php";

?>

</body>
</html>
